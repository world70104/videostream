package org.easydarwin.push;

public interface VideoConsumerWrapper extends VideoConsumer{
}
