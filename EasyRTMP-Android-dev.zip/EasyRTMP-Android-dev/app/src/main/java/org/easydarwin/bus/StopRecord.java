package org.easydarwin.bus;

/**
 * Created by apple on 2017/7/21.
 */

public class StopRecord {
}
